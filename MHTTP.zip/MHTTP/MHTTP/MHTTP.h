//
//  MHTTP.h
//  MHTTP
//
//  Created by Marian on 6/13/17.
//  Copyright © 2017 Marian. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for MHTTP.
FOUNDATION_EXPORT double MHTTPVersionNumber;

//! Project version string for MHTTP.
FOUNDATION_EXPORT const unsigned char MHTTPVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <MHTTP/PublicHeader.h>


#import <MHTTP/TasksManager.h">
